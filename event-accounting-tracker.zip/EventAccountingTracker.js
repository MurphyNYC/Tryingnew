
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Trash2, Save, Download } from "lucide-react";

const EventAccountingTracker = () => {
  const loadSavedData = () => {
    try {
      const savedData = localStorage.getItem('eventAccountingData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        setEventDetails(parsed.eventDetails);
        setRevenue(parsed.revenue);
        setExpenses(parsed.expenses);
        setPayouts(parsed.payouts);
        setAdditionalNotes(parsed.additionalNotes);
      }
    } catch (error) {
      console.error('Error loading saved data:', error);
    }
  };

  const [eventDetails, setEventDetails] = useState({
    name: '', venue: '', date: '', notes: ''
  });
  const [revenue, setRevenue] = useState([{ source: '', amount: '', notes: '' }]);
  const [expenses, setExpenses] = useState([{ type: '', amount: '', vendor: '' }]);
  const [payouts, setPayouts] = useState([{ recipient: '', amount: '', percentage: '' }]);
  const [additionalNotes, setAdditionalNotes] = useState('');

  useEffect(() => { loadSavedData(); }, []);

  const saveData = () => {
    try {
      const dataToSave = { eventDetails, revenue, expenses, payouts, additionalNotes };
      localStorage.setItem('eventAccountingData', JSON.stringify(dataToSave));
      alert('Data saved successfully!');
    } catch (error) {
      console.error('Error saving data:', error);
    }
  };

  const exportData = () => {
    try {
      const dataToExport = {
        eventDetails, revenue, expenses, payouts, additionalNotes,
        summary: {
          totalRevenue: calculateTotal(revenue),
          totalExpenses: calculateTotal(expenses),
          totalPayouts: calculateTotal(payouts),
          netProfit: calculateTotal(revenue) - calculateTotal(expenses)
        }
      };
      const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `event-accounting-${eventDetails.name || 'untitled'}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting data:', error);
    }
  };

  const calculateTotal = (items, field = 'amount') => {
    return items.reduce((sum, item) => sum + parseFloat(item[field] || 0), 0);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <button onClick={saveData} className="bg-blue-600 text-white px-4 py-2 rounded">Save Data</button>
      <button onClick={exportData} className="bg-green-600 text-white px-4 py-2 rounded">Export Data</button>
    </div>
  );
};

export default EventAccountingTracker;
