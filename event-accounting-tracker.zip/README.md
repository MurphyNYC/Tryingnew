
# Event Accounting Tracker

This is a React application that helps you manage event finances, including tracking revenue, expenses, and payouts.

## How to Run

1. Make sure you have Node.js installed.
2. Open a terminal and navigate to the project directory.
3. Run the following commands:

```bash
npm install
npm run dev
```

4. Access the app in your browser at `http://localhost:3000`.

## Features
- Save event data to local storage.
- Export event data as a JSON file.
